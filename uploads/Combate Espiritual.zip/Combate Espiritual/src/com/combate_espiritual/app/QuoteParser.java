package com.combateespiritual.app;

import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.content.Context;
import android.util.Log;

public class QuoteParser {
    private List<Quote> quotes = new ArrayList<>();
    private Random random = new Random();
    private Context context;
    
    public QuoteParser(Context context, String bookText) {
        this.context = context;
        parseBook(bookText);
        saveQuotesToDatabase();
    }
    
    private void parseBook(String bookText) {
        String[] chapters = extractChapters(bookText);
        
        for (int i = 0; i < chapters.length; i++) {
            List<Quote> chapterQuotes = extractQuotesFromChapter(chapters[i], i + 1);
            quotes.addAll(chapterQuotes);
        }
        
        Log.d("QuoteParser", "Parsed " + quotes.size() + " quotes from book");
    }
    
    private String[] extractChapters(String bookText) {
        // Split by chapters (CAPÍTULO followed by Roman numerals)
        String[] chapters = bookText.split("CAPÍTULO\\s+[IVXLCDM]+\\s*\\n");
        // First part is usually introduction, skip it
        if (chapters.length > 1) {
            String[] actualChapters = new String[chapters.length - 1];
            System.arraycopy(chapters, 1, actualChapters, 0, chapters.length - 1);
            return actualChapters;
        }
        return new String[0];
    }
    
    private List<Quote> extractQuotesFromChapter(String chapterText, int chapterNumber) {
        List<Quote> chapterQuotes = new ArrayList<>();
        if (chapterText == null || chapterText.trim().isEmpty()) {
            return chapterQuotes;
        }
        
        String[] sentences = chapterText.split("[.!?]+");
        
        for (int i = 0; i < sentences.length; i++) {
            String sentence = sentences[i].replaceAll("[\\n\\r]+", " ").trim();
            
            if (isMeaningfulQuote(sentence)) {
                Quote quote = new Quote();
                quote.text = sentence + ".";
                quote.reference = "Capítulo " + toRoman(chapterNumber);
                quote.id = "ch" + chapterNumber + "_" + i;
                chapterQuotes.add(quote);
            }
        }
        
        return chapterQuotes;
    }
    
    private boolean isMeaningfulQuote(String sentence) {
        if (sentence == null || sentence.length() < 30 || sentence.length() > 400) return false;
        
        String[] keywords = {
            "dios", "señor", "cristo", "jesús", "alma", "espíritu", "virtud", "vicio",
            "oración", "paciencia", "humildad", "caridad", "amor", "cruz", "pasión",
            "mortificación", "perfección", "gracia", "pecado", "tentación", "combate",
            "voluntad", "corazón", "entendimiento", "naturaleza", "mundo", "demonio"
        };
        
        String lowerSentence = sentence.toLowerCase();
        for (String keyword : keywords) {
            if (lowerSentence.contains(keyword)) {
                int wordCount = sentence.split("\\s+").length;
                return wordCount >= 8 && wordCount <= 80;
            }
        }
        
        return false;
    }
    
    private String toRoman(int num) {
        String[] romanNumerals = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X",
            "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX",
            "XXI", "XXII", "XXIII", "XXIV", "XXV", "XXVI", "XXVII", "XXVIII", "XXIX", "XXX",
            "XXXI", "XXXII", "XXXIII", "XXXIV", "XXXV", "XXXVI", "XXXVII", "XXXVIII", "XXXIX", "XL"};
        return num >= 0 && num < romanNumerals.length ? romanNumerals[num] : String.valueOf(num);
    }
    
    private void saveQuotesToDatabase() {
        QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
        
        // Only save if database is empty
        if (!dbHelper.hasQuotes()) {
            Log.d("QuoteParser", "Saving " + quotes.size() + " quotes to database");
            for (Quote quote : quotes) {
                dbHelper.addQuote(quote);
            }
        } else {
            Log.d("QuoteParser", "Database already has quotes, skipping save");
        }
        dbHelper.close();
    }
    
    public Quote getRandomQuote() {
        QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
        Quote quote = dbHelper.getRandomQuote();
        dbHelper.close();
        return quote;
    }
    
    public List<Quote> getFavoriteQuotes() {
        QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
        List<Quote> favorites = dbHelper.getFavoriteQuotes();
        dbHelper.close();
        return favorites;
    }
    
    public void toggleFavorite(String quoteId, boolean isFavorite) {
        QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
        dbHelper.toggleFavorite(quoteId, isFavorite);
        dbHelper.close();
    }
    
    public int getQuoteCount() {
        QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
        int count = dbHelper.getQuoteCount();
        dbHelper.close();
        return count;
    }
    
    public static class Quote {
        public String text;
        public String reference;
        public String id;
        public boolean isFavorite;
        
        public JSONObject toJSON() throws JSONException {
            JSONObject json = new JSONObject();
            json.put("text", text);
            json.put("reference", reference);
            json.put("id", id);
            json.put("isFavorite", isFavorite);
            return json;
        }
        
        public static Quote fromJSON(JSONObject json) throws JSONException {
            Quote quote = new Quote();
            quote.text = json.getString("text");
            quote.reference = json.getString("reference");
            quote.id = json.getString("id");
            quote.isFavorite = json.optBoolean("isFavorite", false);
            return quote;
        }
    }
}