package com.combateespiritual.app;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import java.util.Calendar;
import android.os.Build;
import android.util.Log;

public class NotificationService extends Service {
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("NotificationService", "Service started");
        rescheduleNotifications();
        return START_STICKY;
    }
    
    private void rescheduleNotifications() {
        SharedPreferences sp = getSharedPreferences("quotes_data", MODE_PRIVATE);
        boolean notificationsEnabled = sp.getBoolean("notifications", true);
        
        if (!notificationsEnabled) {
            Log.d("NotificationService", "Notifications disabled, skipping reschedule");
            return;
        }
        
        String timeStr = sp.getString("notification_time", "08:00");
        String[] parts = timeStr.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        
        // If the time has already passed today, schedule for tomorrow
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
            Log.d("NotificationService", "Time passed, scheduling for tomorrow");
        }
        
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.setAction("com.combateespiritual.app.ACTION_SHOW_QUOTE");
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            this, 
            100, 
            intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
                Log.d("NotificationService", "Scheduled with setExactAndAllowWhileIdle");
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
                Log.d("NotificationService", "Scheduled with setExact");
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
                Log.d("NotificationService", "Scheduled with set");
            }
            Log.d("NotificationService", "Notification scheduled for: " + calendar.getTime());
        } else {
            Log.e("NotificationService", "AlarmManager is null");
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("NotificationService", "Service destroyed");
    }
}