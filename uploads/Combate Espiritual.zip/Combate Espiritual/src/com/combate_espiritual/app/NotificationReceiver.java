package com.combateespiritual.app;

import android.content.*;
import android.app.*;
import android.os.*;
import java.util.*;
import android.graphics.Color;
import android.util.Log;

public class NotificationReceiver extends BroadcastReceiver {
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d("NotificationReceiver", "Received action: " + action);
        
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || 
            "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            // Device rebooted - reschedule notifications
            Log.d("NotificationReceiver", "Device rebooted, rescheduling notifications");
            rescheduleNotifications(context);
        } else if ("com.combateespiritual.app.ACTION_SHOW_QUOTE".equals(action)) {
            // Show daily quote notification
            Log.d("NotificationReceiver", "Showing daily quote notification");
            showDailyQuote(context, intent);
            
            // Reschedule for next day
            rescheduleNotifications(context);
        }
    }
    
    private void showDailyQuote(Context context, Intent intent) {
        SharedPreferences sp = context.getSharedPreferences("quotes_data", Context.MODE_PRIVATE);
        boolean enabled = sp.getBoolean("notifications", true);
        
        if (!enabled) {
            Log.d("NotificationReceiver", "Notifications disabled, skipping");
            return;
        }
        
        sendNotification(context, intent);
    }
    
    private void rescheduleNotifications(Context context) {
        // This will be handled by MainActivity when it starts
        Intent serviceIntent = new Intent(context, NotificationService.class);
        context.startService(serviceIntent);
        Log.d("NotificationReceiver", "Rescheduling notifications via service");
    }
    
    private void sendNotification(Context context, Intent intent) {
        QuoteParser.Quote quote;
        
        // Check if quote was passed in the intent (for test notifications)
        if (intent.hasExtra("quote_text") && intent.hasExtra("quote_reference")) {
            quote = new QuoteParser.Quote();
            quote.text = intent.getStringExtra("quote_text");
            quote.reference = intent.getStringExtra("quote_reference");
            quote.id = "test";
            Log.d("NotificationReceiver", "Using quote from intent");
        } else {
            // Get quote from database
            QuoteDatabaseHelper dbHelper = new QuoteDatabaseHelper(context);
            quote = dbHelper.getRandomQuote();
            dbHelper.close();
            Log.d("NotificationReceiver", "Using random quote from database: " + quote.id);
        }
        
        Intent mainIntent = new Intent(context, MainActivity.class);
        mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 0, mainIntent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        
        // Build notification with full text (no truncation)
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(context, "daily_quotes");
        } else {
            builder = new Notification.Builder(context);
        }
        
        // Create notification with full quote text
        builder.setContentTitle("💫 Combate Espiritual")
               .setContentText("Tu cita diaria está lista")
               .setStyle(new Notification.BigTextStyle()
                   .bigText(quote.text + "\n\n— " + quote.reference)
                   .setBigContentTitle("Cita del Día")
                   .setSummaryText("Lorenzo Scúpoli"))
               .setSmallIcon(android.R.drawable.ic_dialog_info)
               .setColor(Color.parseColor("#8b7355"))
               .setContentIntent(pi)
               .setAutoCancel(true)
               .setWhen(System.currentTimeMillis())
               .setShowWhen(true)
               .setPriority(Notification.PRIORITY_HIGH);
        
        // Add vibration if enabled
        SharedPreferences sp = context.getSharedPreferences("quotes_data", Context.MODE_PRIVATE);
        boolean vibration = sp.getBoolean("vibration", true);
        if (vibration) {
            builder.setVibrate(new long[]{0, 500, 200, 500});
            Log.d("NotificationReceiver", "Vibration enabled");
        }
        
        // Add default sound and lights
        builder.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_LIGHTS);
        
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(1001, builder.build());
            Log.d("NotificationReceiver", "Notification sent successfully");
        } else {
            Log.e("NotificationReceiver", "NotificationManager is null");
        }
    }
}