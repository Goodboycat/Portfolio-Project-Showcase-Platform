package com.combateespiritual.app;

import android.app.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import java.util.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.io.*;

public class MainActivity extends Activity {
    
    private WebView webview;
    private SharedPreferences sp;
    private AlarmManager alarmManager;
    private QuoteParser quoteParser;
    private QuoteDatabaseHelper dbHelper;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Create WebView programmatically
        webview = new WebView(this);
        setContentView(webview);
        
        initialize();
        initializeLogic();
    }
    
    private void initialize() {
    sp = getSharedPreferences("quotes_data", MODE_PRIVATE);
    alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
    dbHelper = new QuoteDatabaseHelper(this);
    
    // SIMPLIFIED WebView settings like Parser to File
    WebSettings webSettings = webview.getSettings();
    webSettings.setJavaScriptEnabled(true);
    webSettings.setDomStorageEnabled(true);
    webSettings.setAllowFileAccess(true);
    webSettings.setAllowContentAccess(true);
    
    // FIX TEXT SIZING - ADD THESE LINES:
    webSettings.setTextZoom(100);
    webSettings.setDefaultFontSize(16);
    webSettings.setMinimumFontSize(8);
    webSettings.setMinimumLogicalFontSize(8);
        
    webview.setHorizontalScrollBarEnabled(false);
    webview.setScrollbarFadingEnabled(true);
    webview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    
    webview.setWebViewClient(new WebViewClient() {
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    });
    
    webview.addJavascriptInterface(new WebAppInterface(), "Android");
    createNotificationChannel();
    
    // Initialize quote parser
    initializeQuoteParser();
}
    
    private void initializeQuoteParser() {
        try {
            // Load book from assets
            InputStream is = getAssets().open("combate_espiritual-culto.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder bookText = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                bookText.append(line).append("\n");
            }
            reader.close();
            
            quoteParser = new QuoteParser(this, bookText.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            // Fallback to empty parser
            quoteParser = new QuoteParser(this, "");
        }
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "daily_quotes", "Citas Diarias", NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Notificaciones de citas del Combate Espiritual");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    private void initializeLogic() {
    webview.loadUrl("file:///android_asset/index.html");
    scheduleDailyNotification();
}
    
    public class WebAppInterface {
        
        @JavascriptInterface
        public void vibrate(int duration) {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                boolean enabled = sp.getBoolean("vibration", true);
                if (enabled) {
                    vibrator.vibrate(duration);
                }
            }
        }
        
        @JavascriptInterface
        public void toast(final String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
        }
        
        @JavascriptInterface
        public void saveData(String key, String value) {
            sp.edit().putString(key, value).apply();
            
            if (key.equals("notification_time") || key.equals("notifications")) {
                cancelExistingNotifications();
                scheduleDailyNotification();
            }
        }
        
        @JavascriptInterface
        public String getData(String key, String defaultValue) {
            return sp.getString(key, defaultValue);
        }
        
        @JavascriptInterface
        public void shareQuote(String text) {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(shareIntent, "Compartir cita"));
        }
        
        @JavascriptInterface
        public String getRandomQuote() {
            try {
                QuoteParser.Quote quote = quoteParser.getRandomQuote();
                return quote.toJSON().toString();
            } catch (Exception e) {
                try {
                    JSONObject json = new JSONObject();
                    json.put("text", "Error cargando cita");
                    json.put("reference", "Sistema");
                    json.put("id", "error");
                    return json.toString();
                } catch (JSONException je) {
                    return "{\"text\":\"Error\",\"reference\":\"\",\"id\":0}";
                }
            }
        }
        
        @JavascriptInterface
        public String getFavorites() {
            try {
                List<QuoteParser.Quote> favorites = quoteParser.getFavoriteQuotes();
                JSONArray jsonArray = new JSONArray();
                for (QuoteParser.Quote quote : favorites) {
                    jsonArray.put(quote.toJSON());
                }
                return jsonArray.toString();
            } catch (Exception e) {
                return "[]";
            }
        }
        
        @JavascriptInterface
        public void toggleFavorite(String quoteId, boolean isFavorite) {
            quoteParser.toggleFavorite(quoteId, isFavorite);
        }
        
        @JavascriptInterface
        public void testNotification() {
            // Get a fresh quote for the test notification
            QuoteParser.Quote quote = quoteParser.getRandomQuote();
            
            Intent intent = new Intent(MainActivity.this, NotificationReceiver.class);
            intent.setAction("com.combateespiritual.app.ACTION_SHOW_QUOTE");
            // Pass the quote as extra
            intent.putExtra("quote_text", quote.text);
            intent.putExtra("quote_reference", quote.reference);
            sendBroadcast(intent);
            toast("Notificación de prueba enviada");
        }
    }
    
    private void scheduleDailyNotification() {
        boolean notificationsEnabled = sp.getBoolean("notifications", true);
        if (!notificationsEnabled) return;
        
        String timeStr = sp.getString("notification_time", "08:00");
        String[] parts = timeStr.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);
        
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }
        
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.setAction("com.combateespiritual.app.ACTION_SHOW_QUOTE");
        
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            this, 100, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        if (alarmManager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, 
                    calendar.getTimeInMillis(), pendingIntent);
            }
        }
    }
    
    private void cancelExistingNotifications() {
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            this, 100, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
        
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(1001);
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
        cancelExistingNotifications();
    }
}