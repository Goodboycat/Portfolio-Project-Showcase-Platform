package com.combateespiritual.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;
import android.util.Log;

public class QuoteDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "quotes.db";
    private static final int DATABASE_VERSION = 1;
    
    // Table name and columns
    public static final String TABLE_QUOTES = "quotes";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TEXT = "text";
    public static final String COLUMN_REFERENCE = "reference";
    public static final String COLUMN_IS_USED = "is_used";
    public static final String COLUMN_IS_FAVORITE = "is_favorite";
    public static final String COLUMN_CREATED_AT = "created_at";
    
    public QuoteDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_QUOTES_TABLE = "CREATE TABLE " + TABLE_QUOTES + "("
                + COLUMN_ID + " TEXT PRIMARY KEY,"
                + COLUMN_TEXT + " TEXT,"
                + COLUMN_REFERENCE + " TEXT,"
                + COLUMN_IS_USED + " INTEGER DEFAULT 0,"
                + COLUMN_IS_FAVORITE + " INTEGER DEFAULT 0,"
                + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(CREATE_QUOTES_TABLE);
        Log.d("QuoteDatabase", "Database created successfully");
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUOTES);
        onCreate(db);
    }
    
    // Add a quote to the database
    public void addQuote(QuoteParser.Quote quote) {
        SQLiteDatabase db = this.getWritableDatabase();
        
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, quote.id);
        values.put(COLUMN_TEXT, quote.text);
        values.put(COLUMN_REFERENCE, quote.reference);
        
        // Insert or replace if exists
        db.insertWithOnConflict(TABLE_QUOTES, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }
    
    // Get a random unused quote
    public QuoteParser.Quote getRandomQuote() {
        SQLiteDatabase db = this.getReadableDatabase();
        QuoteParser.Quote quote = new QuoteParser.Quote();
        
        // First try to get an unused quote
        Cursor cursor = db.query(TABLE_QUOTES,
                new String[]{COLUMN_ID, COLUMN_TEXT, COLUMN_REFERENCE},
                COLUMN_IS_USED + " = ?",
                new String[]{"0"},
                null, null, "RANDOM()", "1");
        
        if (cursor != null && cursor.moveToFirst()) {
            quote.id = cursor.getString(0);
            quote.text = cursor.getString(1);
            quote.reference = cursor.getString(2);
            
            // Mark as used
            markQuoteAsUsed(quote.id);
            cursor.close();
            Log.d("QuoteDatabase", "Got random quote: " + quote.id);
        } else {
            // If all quotes are used, reset and try again
            Log.d("QuoteDatabase", "All quotes used, resetting...");
            resetUsedQuotes();
            cursor = db.query(TABLE_QUOTES,
                    new String[]{COLUMN_ID, COLUMN_TEXT, COLUMN_REFERENCE},
                    null, null, null, null, "RANDOM()", "1");
            
            if (cursor != null && cursor.moveToFirst()) {
                quote.id = cursor.getString(0);
                quote.text = cursor.getString(1);
                quote.reference = cursor.getString(2);
                markQuoteAsUsed(quote.id);
                cursor.close();
            }
        }
        db.close();
        return quote;
    }
    
    // Mark a quote as used
    private void markQuoteAsUsed(String quoteId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IS_USED, 1);
        db.update(TABLE_QUOTES, values, COLUMN_ID + " = ?", new String[]{quoteId});
        db.close();
    }
    
    // Reset all used quotes
    private void resetUsedQuotes() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IS_USED, 0);
        db.update(TABLE_QUOTES, values, null, null);
        db.close();
        Log.d("QuoteDatabase", "Reset all used quotes");
    }
    
    // Get all favorite quotes
    public List<QuoteParser.Quote> getFavoriteQuotes() {
        List<QuoteParser.Quote> favorites = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        
        Cursor cursor = db.query(TABLE_QUOTES,
                new String[]{COLUMN_ID, COLUMN_TEXT, COLUMN_REFERENCE},
                COLUMN_IS_FAVORITE + " = ?",
                new String[]{"1"},
                null, null, COLUMN_CREATED_AT + " DESC");
        
        if (cursor != null) {
            while (cursor.moveToNext()) {
                QuoteParser.Quote quote = new QuoteParser.Quote();
                quote.id = cursor.getString(0);
                quote.text = cursor.getString(1);
                quote.reference = cursor.getString(2);
                quote.isFavorite = true;
                favorites.add(quote);
            }
            cursor.close();
        }
        db.close();
        Log.d("QuoteDatabase", "Retrieved " + favorites.size() + " favorite quotes");
        return favorites;
    }
    
    // Toggle favorite status
    public void toggleFavorite(String quoteId, boolean isFavorite) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IS_FAVORITE, isFavorite ? 1 : 0);
        int rows = db.update(TABLE_QUOTES, values, COLUMN_ID + " = ?", new String[]{quoteId});
        db.close();
        Log.d("QuoteDatabase", "Toggled favorite for quote " + quoteId + " to " + isFavorite + " (rows affected: " + rows + ")");
    }
    
    // Check if database has quotes
    public boolean hasQuotes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_QUOTES, null);
        boolean hasData = false;
        if (cursor != null) {
            cursor.moveToFirst();
            hasData = cursor.getInt(0) > 0;
            cursor.close();
        }
        db.close();
        Log.d("QuoteDatabase", "Database has quotes: " + hasData);
        return hasData;
    }
    
    // Get quote count
    public int getQuoteCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_QUOTES, null);
        int count = 0;
        if (cursor != null) {
            cursor.moveToFirst();
            count = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        Log.d("QuoteDatabase", "Total quotes in database: " + count);
        return count;
    }
}